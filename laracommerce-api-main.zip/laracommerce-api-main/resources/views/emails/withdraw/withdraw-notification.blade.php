<x-mail::message>
# The withdraw request with Id {{ $id }} is {{ $status }}

## for detailed withdraw request information, you can visit the finance menu in your merchant account

Thank you for using our application!<br>
{{ config('app.name') }}
</x-mail::message>
