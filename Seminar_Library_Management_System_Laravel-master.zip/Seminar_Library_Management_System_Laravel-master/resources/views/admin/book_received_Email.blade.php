<!DOCTYPE html>
<html>
<head>
    <title>Seminar Library Management System</title>
</head>
<body>
    <h1>{{ $details_received['title'] }}</h1>
    <p>{{ $details_received['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>