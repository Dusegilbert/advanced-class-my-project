<!DOCTYPE html>
<html>
<head>
    <title>Seminar Library Management System</title>
</head>
<body>
    <h1>{{ $details_remove['title'] }}</h1>
    <p>{{ $details_remove['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>