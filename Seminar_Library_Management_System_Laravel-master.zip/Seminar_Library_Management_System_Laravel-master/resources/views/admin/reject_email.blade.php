<!DOCTYPE html>
<html>
<head>
    <title>Rejected your account</title>
</head>
<body>
    <h1>{{ $details_reject['title'] }}</h1>
    <p>{{ $details_reject['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>