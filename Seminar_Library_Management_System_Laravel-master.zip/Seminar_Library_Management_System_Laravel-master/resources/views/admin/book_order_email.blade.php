<!DOCTYPE html>
<html>
<head>
    <title>Seminar Library Management System</title>
</head>
<body>
    <h1>{{ $details_order['title'] }}</h1>
    <p>{{ $details_order['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>