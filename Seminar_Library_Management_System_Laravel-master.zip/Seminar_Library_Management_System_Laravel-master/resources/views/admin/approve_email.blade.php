<!DOCTYPE html>
<html>
<head>
    <title>Seminar Library Management System</title>
</head>
<body>
    <h1>{{ $details_approve['title'] }}</h1>
    <p>{{ $details_approve['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>