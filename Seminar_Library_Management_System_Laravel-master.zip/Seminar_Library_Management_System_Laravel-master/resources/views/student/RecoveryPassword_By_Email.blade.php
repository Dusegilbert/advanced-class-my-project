<!DOCTYPE html>
<html>
<head>
    <title>Recover Password</title>
</head>
<body>
    <h1>{{ $details2['title'] }}</h1>
    <p>{{ $details2['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>