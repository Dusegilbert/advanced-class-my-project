# Hi there 👋

- 🔭 I’m currently looking for a job as a dev
- 🌱 I’m currently learning Web3 development 
- 👯 I’m looking to collaborate in Laravel
- 💬 Ask me about Web2 Development
- 📫 How to reach me: tauseedzaman@pm.me
- 😄 Pronouns: tauseedzaman
- ⚡ Fun fact: Father of a Web2.0 😁

### Tech Stack


<a href="#"><img align="left" alt="bootstrap" title="bootstrap" width="21px" src="https://cdn.worldvectorlogo.com/logos/bootstrap-icon.svg" /></a>
<a href="#"><img align="left" alt="sass" title="sass" width="21px" src="https://cdn.worldvectorlogo.com/logos/sass-1.svg" /></a>
<a href="#"><img align="left" alt="tailwind" title="tailwind" width="21px" src="https://cdn.worldvectorlogo.com/logos/tailwind-css-2.svg" /></a>
<a href="#"><img align="left" alt="python" title="python" width="21px" src="https://cdn.worldvectorlogo.com/logos/python-5.svg" /></a>
<a href="#"><img align="left" alt="linux" title="linux" width="21px" src="https://cdn.worldvectorlogo.com/logos/linux-tux.svg" /></a>
<a href="#"><img align="left" alt="git bash" title="git bash" width="21px" src="https://cdn.worldvectorlogo.com/logos/git-bash.svg" /></a>
<a href="#"><img align="left" alt="bash" title="bash" width="25px" src="https://cdn.worldvectorlogo.com/logos/bash-1.svg" /></a>
<a href="laravel.com"><img align="left" alt="laravel" title="laravel" width="21px" src="https://cdn.worldvectorlogo.com/logos/laravel-2.svg" /></a>
<a href="php.net"><img align="left" alt="php" title="php" width="21px" src="https://cdn.worldvectorlogo.com/logos/php-1.svg" /></a>
<a href="#"><img align="left" alt="mysql" title="mysql" width="21px" src="https://cdn.worldvectorlogo.com/logos/mysql-6.svg" /></a>

 <a href="#"><img align="left" alt="Laravel" title="Laravel" width="21px" src="https://upload.wikimedia.org/wikipedia/commons/9/99/Unofficial_JavaScript_logo_2.svg" /></a>

<a href="#"><img align="left" alt="npm" title="npm" width="29px" src="https://cdn.worldvectorlogo.com/logos/npm.svg" /></a>
<a href="#"><img align="left" alt="express" title="express" width="29px" src="https://www.pngfind.com/images/lazy-bg.png"/></a>
<a href="vuejs.org"><img align="left" alt="svlet" title="svlet" width="21px" src="https://cdn.worldvectorlogo.com/logos/svelte-1.svg" /></a>
<a href="vuejs.org"><img align="left" alt="alpine" title="alpine" width="21px" src="https://cdn.worldvectorlogo.com/logos/alpine-13.svg" /></a>
 <a href="vuejs.org"><img align="left" alt="vue" title="vue" width="21px" src="https://cdn.worldvectorlogo.com/logos/vue-9.svg" /></a>
  <a href="nuxtjs.org"><img align="left" alt="vue nuxt" title="vue nuxt" width="21px" src="https://cdn.worldvectorlogo.com/logos/nuxt-2.svg" /></a>
  <a href="https://nodejs.org/"><img align="left" alt="NodeJS" title="NodeJS" width="21px" src="https://seeklogo.com/images/N/nodejs-logo-FBE122E377-seeklogo.com.png" /></a>
  <a href="https://reactjs.org/"><img align="left" alt="React" title="React" width="21px" src="https://cdn.worldvectorlogo.com/logos/react-2.svg" /></a>
  <a href="https://hapi.dev/"><img align="left" alt="Hapi" title="Hapi (NodeJS HTTP Framework)" width="21px" src="https://avatars.githubusercontent.com/u/3774533?s=200&v=4" /></a>
  <a href="https://nextjs.org/"><img align="left" alt="Next" title="Next (React SSR Framework)" width="21px" src="https://iconape.com/wp-content/files/gm/82643/svg/next-js.svg" /></a>
  <br>
  <br>
  
### Github Statistic
<p align="left">
<a href="https://github.com/tauseedzaman">
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api?username=tauseedzaman&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=tauseedzaman&layout=compact&langs_count=8&theme=algolia"/>
</a>
</p>

