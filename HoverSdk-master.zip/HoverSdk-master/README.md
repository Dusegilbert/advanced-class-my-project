# HoverSDK
HoverSDK App is a very simple Android app built with the Hover SDK

# Prerequisites
Hover Account

Basic Familiarity with Android Studio

# HoverSDK
From your Hover dashboard, create an app and give it a name of your choice, eg. "Hover". Use the applicationId as the package name. Save the app and note the API token.
In AndroidManifest.xml, replace "YOUR_API_KEY" with the token you just created. Then open MainActivity.java and add your action ID from  to the onClickListener for action_button.

# Build and run
Build and run the app. Tap the "REQUEST PERMISSIONS" button first and follow the prompts. Finally, tap the "RUN ACTION" button to run the test action.
