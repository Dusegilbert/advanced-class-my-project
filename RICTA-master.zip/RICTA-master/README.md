# RICTA API USING MERN STACK

## Backend
- First of all install all modules by using `npm init`

## Frontend
- Create a React-app using `Vite build tool` and also install missing modules.
- `https://vitejs.dev/guide/` Use this link to see how you can get started with vite.

## Credits
* Kudos to Muslim 👏, who helped me out when i was stuck.

⚠ RMK: It's an open source toy project anyone can contribute to it. 😁

Best Regards
