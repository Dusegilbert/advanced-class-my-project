# Cars-renting-information-system
you will find to forms for login and signup then select your role  if you are admin use information of admin you have given below  if you  are not it means you are client  so you have to use client information you have given below but as role of admin you can create new client who is able to login,view cars and logout.
