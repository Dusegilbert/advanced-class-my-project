### Hey there <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">

<a href="https://twitter.com/SajeebChakrabo8">
  <img align="left" alt="Sajeeb Chakraborty | Twitter" width="22px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/twitter.svg" />
</a>
<a href="https://www.linkedin.com/in/sajeeb-chakraborty-1b944a163/">
  <img align="left" alt="Sajeeb's LinkedIN" width="22px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/linkedin.svg" />
</a>

 

![](https://visitor-badge.glitch.me/badge?page_id=SajeebChakraborty)

<br />

<a href="https://www.facebook.com/sajeeb.chakraborty">
    <i class="fa-brands fa-facebook">My Facebook</i>
 </a>
 
 <br />
 
 <br />
 
 <a href="https://docs.google.com/document/d/1P0018ZrIdnlb_GftNasHyHzSDbQuKsQ6nYqGm7MM1lM/edit?usp=sharing">
    <i class="">My Project List</i>
 </a>
 
 <br />
 
 <br />
 
 ![expert-at-laravel](https://user-images.githubusercontent.com/48250220/231816227-f633193a-c2c9-4e56-a829-e62800203f6d.svg)

Hi, I'm [Sajeeb Chakraborty!](https://github.com/SajeebChakraborty), a Full Stack Web Developer 🚀 from Bangladesh.

  
**Talking about Personal Topics:**

- 👨🏽‍💻 I’m currently working on Laravel, React js and Vue js;
- 🌱 I’m currently learning Node js, Express js and AI; 
- 💬 Ask me about anything, I am happy to help;
- 📫 How to reach me: [Sajeeb Chakraborty](https://www.facebook.com/sajeeb.chakraborty);
- 💬 Contact no - 01824072334 (mobile & whatsapp)
- 🌱 Email address - sajeebchakraborty.cse2000@gmail.com
- 📫 Portfolio Link - https://sajeebchakraborty.github.io
- 📫 My CV - https://drive.google.com/file/d/1l2nBoxkNpzXWplbpWCOTeiKaqiplsh2s/view?usp=share_link


**Languages, Framework, Library & Tools:**  

<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/laravel/laravel.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/php/php.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/java/java.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/bootstrap/bootstrap.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/npm/npm.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mongoose/mongoose.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>


📈 My GitHub Stats

![My GitHub stats-Dark](https://github-readme-stats.vercel.app/api?username=SajeebChakraborty&show_icons=true&theme=dark#gh-dark-mode-only)






